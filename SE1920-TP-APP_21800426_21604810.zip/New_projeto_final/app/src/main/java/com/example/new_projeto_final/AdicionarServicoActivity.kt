package com.example.new_projeto_final

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_adicionar_servico.*

class AdicionarServicoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adicionar_servico)

        btSave.setOnClickListener {
            if (editNomeServico.text.isEmpty()){
                Toast.makeText(this, "Introduza o nome do serviço", Toast.LENGTH_SHORT).show()
                editNomeServico.requestFocus()
                if (editPrecoHora.text.isEmpty()){
                    Toast.makeText(this, "Introduza preço por hora", Toast.LENGTH_SHORT).show()
                }
            }else{
                val servico = Servico()
                servico.nomeServico = editNomeServico.text.toString()
                if (editPrecoHora.text.isEmpty()){
                    Toast.makeText(this, "Introduza preço por hora", Toast.LENGTH_SHORT).show()
                }else{
                    servico.precoServico = editPrecoHora.text.toString().toDouble()
                    MainActivity.dbHandler.addSerico(this, servico)
                    clearEdits()
                    editNomeServico.requestFocus()
                }
            }
        }

        btCancel1.setOnClickListener {
            clearEdits()
            finish()
        }
    }

    private fun clearEdits(){
        editNomeServico.text.clear()
        editPrecoHora.text.clear()
    }
}
