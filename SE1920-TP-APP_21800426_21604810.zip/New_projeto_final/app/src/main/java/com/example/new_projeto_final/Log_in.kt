package com.example.new_projeto_final

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.new_projeto_final.MainActivity.Companion.preferenceHelper
import kotlinx.android.synthetic.main.activity_adicionar_servico.btCancel1
import kotlinx.android.synthetic.main.activity_log_in.*

class Log_in : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_in)

        btLogin.setOnClickListener {
            if (username.text.isEmpty()){
                Toast.makeText(this, "Introduza o nome de utilizador", Toast.LENGTH_SHORT).show()
                username.requestFocus()
                if (password.text.isEmpty()){
                    Toast.makeText(this, "Introduza password", Toast.LENGTH_SHORT).show()
                    password.requestFocus()
                }
            }else{
                val user = User()
                user.userName = username.text.toString()
                if (password.text.isEmpty()){
                    Toast.makeText(this, "Introduza password", Toast.LENGTH_SHORT).show()
                    password.requestFocus()
                }else{
                    user.passWord = password.text.toString()
                    val isLogIn = MainActivity.dbHandler.logIn(user)
                    if (isLogIn == false){
                        clearEdits()

                    }else {
                        preferenceHelper!!.putIsLogin(true)
                        preferenceHelper!!.putName(user.userName)
                        preferenceHelper!!.putPass(user.passWord)
                        clearEdits()
                        finish()
                    }
                }
            }
        }

        btCancel1.setOnClickListener {
            clearEdits()
            finish()
        }
    }

    private fun clearEdits(){
        username.text.clear()
        password.text.clear()
    }
}

