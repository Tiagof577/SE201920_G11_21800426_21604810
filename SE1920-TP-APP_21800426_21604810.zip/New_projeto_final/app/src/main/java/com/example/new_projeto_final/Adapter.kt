package com.example.new_projeto_final

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_adicionar_servico.view.*
import kotlinx.android.synthetic.main.lo_servico_update.view.*
import kotlinx.android.synthetic.main.lo_servicos.view.*

class ServicoAdapter(mCtx : Context, val servico : ArrayList<Servico>) : RecyclerView.Adapter<ServicoAdapter.ViewHolder>(){

    val mCtx = mCtx

    class ViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView){
        val txtNomeServico = itemView.txtNomeServico
        val txtPrecoHora = itemView.txtPrecoHora
        val btUpdate = itemView.btUpdate
        val btDelete = itemView.btDelete

    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ServicoAdapter.ViewHolder {
        val v = LayoutInflater.from(p0.context).inflate(R.layout.lo_servicos,p0, false)
        return ViewHolder(v)
    }

    override fun getItemCount(): Int {
        return servico.size

    }

    override fun onBindViewHolder(p0: ServicoAdapter.ViewHolder, p1: Int) {
        val servicos : Servico = servico[p1]
        p0.txtNomeServico.text = servicos.nomeServico
        p0.txtPrecoHora.text = servicos.precoServico.toString()

        p0.btDelete.setOnClickListener {
            val  nomeServico = servicos.nomeServico
            var alertDialog = AlertDialog.Builder(mCtx)
                .setTitle("Alerta")
                .setMessage("Tem a certeza que pertende iliminar : $nomeServico ?")
                .setPositiveButton("Sim", DialogInterface.OnClickListener { dialog, which ->
                    if (MainActivity.dbHandler.deleteServico(servicos.servicoID)){
                        servico.removeAt(p1)
                        notifyItemRemoved(p1)
                        notifyItemRangeChanged(p1, servico.size)
                        Toast.makeText(mCtx, "Serviço $nomeServico iliminado", Toast.LENGTH_SHORT).show()
                    }else {
                        Toast.makeText(mCtx, "Erro ao iliminar", Toast.LENGTH_SHORT).show()
                    }
                })
                .setNegativeButton("Não", DialogInterface.OnClickListener { dialog, which ->  })
                .setIcon(R.drawable.ic_warning_black_24dp)
                .show()
        }
        p0.btUpdate.setOnClickListener {
            val inflater = LayoutInflater.from(mCtx)
            val view = inflater.inflate(R.layout.lo_servico_update, null)
            val textServName : TextView = view.findViewById(R.id.editUpNomeservico)
            val textPrecoHora : TextView = view.findViewById(R.id.editUpPrecoHora)
            textServName.text = servicos.nomeServico
            textPrecoHora.text = servicos.precoServico.toString()

            val builder = AlertDialog.Builder(mCtx)
                .setTitle("atualizar Informação de serviço")
                .setView(view)
                .setPositiveButton("atualizar", DialogInterface.OnClickListener { dialog, which ->
                    val isUpdate = MainActivity.dbHandler.updateServico(
                        servicos.servicoID.toString(),
                        view.editUpNomeservico.text.toString(),
                        view.editUpPrecoHora.text.toString())
                    if (isUpdate == true){
                        servico[p1].nomeServico = view.editNomeServico.text.toString()
                        servico[p1].precoServico = view.editPrecoHora.text.toString().toDouble()
                        notifyDataSetChanged()
                        Toast.makeText(mCtx, "atualização bem sucedida", Toast.LENGTH_SHORT).show()
                    }else{
                        Toast.makeText(mCtx, "Erro ao atualizar", Toast.LENGTH_SHORT).show()
                    }

                })
                .setNegativeButton("Cancelar", DialogInterface.OnClickListener { dialog, which ->  })
            val alert = builder.create()
            alert.show()

        }
    }

}