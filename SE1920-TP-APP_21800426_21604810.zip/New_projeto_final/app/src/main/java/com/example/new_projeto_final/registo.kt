package com.example.new_projeto_final

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_log_in.*
import kotlinx.android.synthetic.main.activity_registo.*
import kotlinx.android.synthetic.main.activity_log_in.btCancel1 as btCancel11

class registo : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registo)

        btLogon.setOnClickListener {
            if (username.text.isEmpty()){
                Toast.makeText(this, "Introduza o nome de utilizador", Toast.LENGTH_SHORT).show()
                username.requestFocus()
                if (password.text.isEmpty()){
                    Toast.makeText(this, "Introduza password", Toast.LENGTH_SHORT).show()
                    password.requestFocus()
                }
            }else{
                val user = User()
                user.userName = username.text.toString()
                if (password.text.isEmpty()){
                    Toast.makeText(this, "Introduza password", Toast.LENGTH_SHORT).show()
                    password.requestFocus()
                }else{
                    user.passWord = password1.text.toString()
                    MainActivity.dbHandler.logOn(this, user)
                }
            }
        }

        btCancel1.setOnClickListener {
            clearEdits()

        }
    }

    private fun clearEdits(){
        username.text.clear()
        password.text.clear()
    }
}


