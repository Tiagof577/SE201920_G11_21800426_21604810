package com.example.new_projeto_final

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    companion object{
        lateinit var dbHandler: DBHandler
        lateinit var preferenceHelper: PreferenceHelper
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)

        dbHandler = DBHandler(this, null, null, 1)
        preferenceHelper = PreferenceHelper(this)

        registo()

        viewServico()

        fab.setOnClickListener {
            val i = Intent(this, AdicionarServicoActivity::class.java)
            startActivity(i)
        }

    }
    private fun viewServico(){

        val servicolista = dbHandler.getServicos(this)
        val adapter = ServicoAdapter(this, servicolista)
        val rv : RecyclerView = findViewById(R.id.rv)
        rv.layoutManager = LinearLayoutManager(this, LinearLayout.VERTICAL, false) as RecyclerView.LayoutManager
        rv.adapter = adapter
    }

    private fun registo (){

        if(preferenceHelper!!.getIsLogin()){

            val i = Intent(this, registo::class.java)
            startActivity(i)
            val inte = Intent(this, Log_in::class.java)
            startActivity(inte)
            viewServico()
        }else {
            viewServico()
        }
    }

    override fun onResume() {
        viewServico()
        super.onResume()
    }

}
