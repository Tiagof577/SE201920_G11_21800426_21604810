package com.example.new_projeto_final

class Servico {
    var servicoID : Int = 0
    var nomeServico : String = ""
    var precoServico : Double = 0.0
}

class User {
    var userID : Int = 0
    var userName : String = ""
    var passWord : String = ""
}

class LogIN {
    var userID : Int = 0
    var userName : String = ""
    var passWord : String = ""
}