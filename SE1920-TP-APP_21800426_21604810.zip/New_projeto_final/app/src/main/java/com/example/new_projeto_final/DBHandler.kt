package com.example.new_projeto_final

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import android.widget.Toast
import androidx.core.content.contentValuesOf
import kotlin.Exception

class DBHandler (context : Context, name : String?, factory: SQLiteDatabase.CursorFactory?, version : Int) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION ) {

    companion object {
        private val DATABASE_NAME = "Projeto_final.db"
        private val DATABASE_VERSION = 1


        val TABELA_SERVICOS = "servicos"
        val COLUNA_SERVOCO_ID = "id_servico"
        val COLUNA_NOME_SERVICO = "nome_servico"
        val COLUNA_PRECO = "preco"


        val TABELA_UTILIZADORES = "user"
        val COLUNA_USERS_ID = "id_user"
        val COLUNA_USERNAME = "username"
        val COLUNA_PASSWORD = "password"
        val COLUNA_TIPO_USER ="tipo_user"



    }

    override fun onCreate(db: SQLiteDatabase?) {
        val CREATE_TABELA_USER = ("CREATE TABLE $TABELA_UTILIZADORES (" +
                "$COLUNA_USERS_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUNA_USERNAME TEXT, " +
                "$COLUNA_PASSWORD TEXT," +
                "$COLUNA_TIPO_USER INTEGER)")
        db?.execSQL(CREATE_TABELA_USER)

        val CREATE_TABELA_SERVICOS = ("CREATE TABLE $TABELA_SERVICOS (" +
                "$COLUNA_SERVOCO_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUNA_NOME_SERVICO TEXT, " +
                "$COLUNA_PRECO DOUBLE, " +
                "$COLUNA_USERS_ID INTEGER )")
        db?.execSQL(CREATE_TABELA_SERVICOS)



    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

    }

    fun getServicos(mCtx :Context) : ArrayList<Servico>{
        val sqlqry = "Select * From $TABELA_SERVICOS"
        val db = this.readableDatabase
        val cursor = db.rawQuery(sqlqry, null)
        val servicos = ArrayList<Servico>()

        if (cursor.count == 0){
            Toast.makeText(mCtx, "Não existem serviços", Toast.LENGTH_SHORT).show()
        }else {
            while (cursor.moveToNext()){
                val servico = Servico()
                servico.servicoID = cursor.getInt(cursor.getColumnIndex(COLUNA_SERVOCO_ID))
                servico.nomeServico = cursor.getString(cursor.getColumnIndex(COLUNA_NOME_SERVICO))
                servico.precoServico = cursor.getDouble(cursor.getColumnIndex(COLUNA_PRECO))
                servicos.add(servico)
            }
            Toast.makeText(mCtx, "${cursor.count.toString()} serviços encontrados", Toast.LENGTH_SHORT).show()
        }
        cursor.close()
        db.close()
        return  servicos

    }

    fun addSerico(mCtx: Context, servico: Servico){
        val values = ContentValues()
        values.put(COLUNA_NOME_SERVICO,servico.nomeServico)
        values.put(COLUNA_PRECO,servico.precoServico)
        val db = this.writableDatabase
        try {
           db.insert(TABELA_SERVICOS, null,values)
            Toast.makeText(mCtx, "Serviço adicionado", Toast.LENGTH_SHORT).show()
        }catch (e : Exception){
            Toast.makeText(mCtx, e.message, Toast.LENGTH_SHORT).show()
        }
        db.close()
    }
    fun deleteServico(servicoID : Int) : Boolean{
        val sqlqry = "Delete From $TABELA_SERVICOS where $COLUNA_SERVOCO_ID = $servicoID"
        val db = this.writableDatabase
        var result : Boolean = false
        try {
            val cursor = db.execSQL(sqlqry)
            result = true
        }catch (e : Exception){
            Log.e(ContentValues.TAG, "ERRO AO ELIMINAR")
        }
        db.close()
        return result
    }
    fun updateServico(id: String, nomeServico: String, precoServico: String) : Boolean{
        var result : Boolean = false
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(COLUNA_NOME_SERVICO, nomeServico)
        contentValues.put(COLUNA_PRECO, precoServico.toDouble())
        try {
            db.update(TABELA_SERVICOS, contentValues, "$COLUNA_SERVOCO_ID = ?", arrayOf(id))
            result = true
        }catch (e : Exception){
            result = false
            Log.e(ContentValues.TAG, "ERRO NA ATUALIZAÇÃO")
        }
        return result
    }

    fun logIn(user: User) : Boolean {
        var result : Boolean = false
        val db = this.readableDatabase
        val sqlqry = "Select * From $TABELA_UTILIZADORES where $COLUNA_USERNAME = ${user.userName} and $COLUNA_PASSWORD = ${user.passWord}"
        try {
            db.rawQuery(sqlqry, null)
            result = true
        }catch (e : Exception){
            result = false
            Log.e(ContentValues.TAG, "Erro no login")
        }
        return result
    }
    fun logOn(mCtx: Context ,user: User) {
        val values = ContentValues()
        values.put(COLUNA_USERNAME ,user.userName)
        values.put(COLUNA_PASSWORD ,user.passWord)
        val db = this.writableDatabase
        try {
            db.insert(TABELA_UTILIZADORES, null,values)
            Toast.makeText(mCtx, "Serviço adicionado", Toast.LENGTH_SHORT).show()
        }catch (e : Exception){
            Toast.makeText(mCtx, e.message, Toast.LENGTH_SHORT).show()
        }
        db.close()
    }

}